package com.company;

public class Kullanıcı {
    String ad;
    String soyad;
    String adres;

    public Kullanıcı(String ad, String soyad, String adres) {
        this.ad = ad;
        this.soyad = soyad;
        this.adres = adres;
    }
}
