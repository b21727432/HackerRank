package com.company;

import java.util.ArrayList;
import java.util.List;

public class Sepet {
    ArrayList<Ürün> ürün;
    ArrayList<Integer> adet;

}
